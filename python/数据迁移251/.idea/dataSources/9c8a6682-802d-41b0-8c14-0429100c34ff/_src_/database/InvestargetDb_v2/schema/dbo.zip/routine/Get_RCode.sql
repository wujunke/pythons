

CREATE FUNCTION [dbo].[Get_RCode]
(
)
RETURNS nvarchar(50) AS
BEGIN
	DECLARE @maxRequirementCode nvarchar(50)
	DECLARE @TodaylastNum int
	DECLARE @Zero nvarchar(4)
	set @Zero = '0000'

	SELECT @TodaylastNum = count(Id) FROM dbo.Requirement where Code like ('R'+CONVERT(varchar(8), GETDATE(), 112) +'%')
	set @TodaylastNum = @TodaylastNum + 1
	set @Zero =substring(@Zero,1,(len(@Zero)-len(@TodaylastNum)))
	
	set @maxRequirementCode = 'R'+ CONVERT(varchar(8), GETDATE(), 112)+ @Zero + CONVERT(varchar(8), @TodaylastNum) 
	Return @maxRequirementCode
END


