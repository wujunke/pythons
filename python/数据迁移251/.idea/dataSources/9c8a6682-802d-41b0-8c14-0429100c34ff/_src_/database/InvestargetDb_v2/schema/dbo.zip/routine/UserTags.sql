CREATE Procedure [dbo].[UserTags]
AS
set nocount on

DECLARE @id int
DECLARE @Tags nvarchar(100)
DECLARE @Tags1 nvarchar(100)


DECLARE First_cursor CURSOR FOR
select b.id,rtrim(ltrim([Tags])) FROM [xd] a,[user] b where a.mobile = b.mobile
OPEN First_cursor
FETCH NEXT FROM First_cursor
INTO @id,@Tags

WHILE @@FETCH_STATUS = 0
BEGIN
	
	if(@Tags<>'' or @Tags is not null)
		insert into dbo.User_Tags 
		select @id,b.id,0,null,null,null,null,getdate(),null 
		from DBO.F_SQLSERVER_SPLIT(@Tags,'、') a,Tag b where a.short_str = b.TagNameC
		
	--if(@Tags1<>'' or @Tags1 is not null)
	--	insert into dbo.User_Tags 
	--	select @id,b.id,0,null,null,null,null,getdate(),null 
	--	from DBO.F_SQLSERVER_SPLIT(@Tags1,'、') a,Tag b where a.short_str = b.TagNameC
		
	--if not exists(select * from dbo.User_Tags where UserID = @id and TagId = )
	--begin
	--	if(@TitleName<>'' or @TitleName is not null)
	--		select @titleID=id from dbo.Title where TitleC = @TitleName
			
	--		select * from DBO.F_SQLSERVER_SPLIT('生命科学；电子商务；环保节能；TMT','；') a,Tag b where a.short_str = b.TagNameC
		
	--	if(@IndustryID1<>'' or @IndustryID1 is not null)
	--		select @IndustryIDint=id from dbo.Industry where IndustryC = @IndustryID1
	--	else if(@IndustryID<>'' or @IndustryID is not null)
	--		select @IndustryIDint=id from dbo.Industry where IndustryC = @IndustryID
		
	--	if(@Company<>'' or @Company is not null)
	--		select @OrgID=id from dbo.Organization where Name = @Company
			
	--	if(@OrgArea<>'' or @OrgArea is not null)
	--		select @OrgAreaint = id from dbo.OrgArea where AreaName = @OrgArea
		
	--	DECLARE @Code nvarchar(50)
	--	set @Code = 201600000+right(1000000+cast(rand()*10000000 as int)+1,6)
	--	set @Code = 'default'+@Code
		
	--	insert into dbo.[User]([PhotoBucket],
	--							[PhotoKey],
	--							[CardBucket],
	--							[CardKey],
	--							[Mobile],
	--							[WeChat],
	--							[ReferencesId],
	--							[References],
	--							[HeadId],
	--							[Head],
	--							[Sourcesofinformation],
	--							[Gender],
	--							[Company],
	--							[TitleId],
	--							[IndustryId],
	--							[OrganizationId],
	--							[Mandate],
	--							[AuditStatus],
	--							[RegisterSource],
	--							[PartnerId],
	--							[PartnerName],
	--							[Score],
	--							[UserType],
	--							[AuthenticationSource],
	--							[Name],
	--							[Surname],
	--							[Password],
	--							[IsEmailConfirmed] ,
	--							[EmailConfirmationCode],
	--							[PasswordResetCode],
	--							[IsActive],
	--							[UserName] ,
	--							[TenantId],
	--							[EmailAddress],
	--							[LastLoginTime],
	--							[IsDeleted],
	--							[DeleterUserId],
	--							[DeletionTime],
	--							[LastModificationTime],
	--							[LastModifierUserId],
	--							[CreationTime],
	--							[CreatorUserId],
	--							[AuditPassTime],
	--							[AuditNotPassTime],
	--							[CountryId],
	--							[OrgAreaId],
	--							[DepartMent])
	--							values (null,null,null,null,@mobile,@wechat,null,null,164,'樊杨阳',@inforID,0,
	--							@Company,@titleID,@IndustryIDint,@OrgID,0,2,4,@parenterID,@parenterName,null,1,null,@Name,@Name,'e10adc3949ba59abbe56e057f20f883e',
	--							1,null,null,1,@Code,1,@eMail,null,0,null,null,null,null,getdate(),null,null,null,42,@OrgAreaint,@DepartMent)
	--end
	--else
	--begin
	--	update dbo.Organization set Currency = @Currencyint where Name = @Name
	--	--if(@DecisionMakingProcess<>'' or @DecisionMakingProcess is not null)
	--	--begin
	--	--	update dbo.Organization set DecisionMakingProcess = @DecisionMakingProcess where Name = @Name
	--	--end
		
	--	--select @id = id from dbo.Organization where Name = @Name
	--	--IF(@OrgLC <>'' OR @OrgLC IS NOT NULL)
	--	--begin
	--	--	 insert into Organization_TransactionPhase select @id, phaseId,0,null,null,null,null,getdate(),null from DBO.F_SQLSERVER_SPLIT(@OrgLC,'；')
	--	--end	
	--end

	
	FETCH NEXT FROM First_cursor
	INTO @id,@Tags
END

CLOSE First_cursor
DEALLOCATE First_cursor