CREATE Procedure [dbo].[OrgCode]
AS
set nocount on

DECLARE @OrgName nvarchar(100)
DECLARE @OrgType nvarchar(100)
DECLARE @webSite nvarchar(100)

DECLARE First_cursor CURSOR FOR
select rtrim(ltrim([OrgType])),rtrim(ltrim([OrgName])),rtrim(ltrim([webSite])) FROM [xd] 
OPEN First_cursor
FETCH NEXT FROM First_cursor
INTO @OrgType,@OrgName,@webSite

WHILE @@FETCH_STATUS = 0
BEGIN
	DECLARE @OrgTypeint int
	--DECLARE @Currencyint int

	if(@OrgType='VC')
		set @OrgTypeint = 1
	--else if(@OrgType='律所')
	--	set @OrgTypeint = 2
	--else if(@OrgType='投行')
	--	set @OrgTypeint = 3
	--else if(@OrgType='个人')
	--	set @OrgTypeint = 4
	--else if(@OrgType='证券')
	--	set @OrgTypeint = 5
	--else if(@OrgType='银行')
	--	set @OrgTypeint = 6
	else if(@OrgType='上市公司')
		set @OrgTypeint = 7
	--else if(@OrgType='新三板上市公司')
	--	set @OrgTypeint = 8
	--else if(@OrgType='非上市公司')
	--	set @OrgTypeint = 9
	--else if(@OrgType='其它')
	--	set @OrgTypeint = 10
	
	--if (@OrgCurrey='人民币')
	--	set @Currencyint = 1
	--else if(@OrgCurrey='美元')
	--	set @Currencyint = 2
	--else if(@OrgCurrey='人民币；美元')
	--	set @Currencyint = 3
		
	
	declare @id int
	if not exists(select * from dbo.Organization where Name = @OrgName)
	begin
		insert into Organization(Description,LocationId,Currency,DecisionCycle,DecisionMakingProcess,LastModificationTime,
		LastModifierUserId,CreationTime,CreatorUserId,Name,OrgType,TransactionAmountF,TransactionAmountT,IsDeleted,DeleterUserId,
		DeletionTime,WeChat,FundSize,Address,TypicalCase,PartnerOrInvestmentCommitteeMember,Phone,WebSite,AuditStatus,AuditPassTime)
		values (null,null,null,null,null,null,null,getdate(),null,@OrgName,@OrgTypeint,null,null,0,null,null,null,
		null,null,null,null,null,@webSite,2,getdate())

	--	select @id = id from dbo.Organization where Name = @OrgName
	--	IF(@OrgLC <>'' OR @OrgLC IS NOT NULL)
	--	begin
	--		 insert into Organization_TransactionPhase select @id, phaseId,0,null,null,null,null,getdate(),null from DBO.F_SQLSERVER_SPLIT(@OrgLC,'、') where id not in
	--		 (select id from dbo.Organization_TransactionPhase where OrganizationId = @id and TransactionPhaseId = phaseId) 
	--	end
	--end
	--else
	--begin
		--update dbo.Organization set Currency = @Currencyint,Description=@OrgJS,OrgType=@OrgTypeint,WeChat=@Wechat,Address=@OrgAddress,
		--TypicalCase=@OrgAL,PartnerOrInvestmentCommitteeMember=@OrgMan,Phone=@OrgPhone,WebSite=@OrgHomePage where Name = @OrgName
		
		--if(@Currencyint = 2)
			--update dbo.Organization set FundSize_USD = cast(REPLACE(REPLACE(@OrgGM,',',''),'USD','')AS bigint) where Name = @OrgName
		--else
			--update dbo.Organization set FundSize = cast(REPLACE(REPLACE(@OrgGM,',',''),'RMB','')AS bigint) where Name = @OrgName
			
		
		--select @id = id from dbo.Organization where Name = @OrgName
		--IF(@OrgLC <>'' OR @OrgLC IS NOT NULL)
		--begin
		--	 insert into Organization_TransactionPhase select @id, phaseId,0,null,null,null,null,getdate(),null from DBO.F_SQLSERVER_SPLIT(@OrgLC,'、') where id not in
		--	 (select id from dbo.Organization_TransactionPhase where OrganizationId = @id and TransactionPhaseId = phaseId) 
		--end	
	end

	
	FETCH NEXT FROM First_cursor
	INTO @OrgType,@OrgName,@webSite
END

CLOSE First_cursor
DEALLOCATE First_cursor