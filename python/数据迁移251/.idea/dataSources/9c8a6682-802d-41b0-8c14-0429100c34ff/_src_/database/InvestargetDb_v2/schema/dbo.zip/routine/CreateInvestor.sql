  
CREATE Procedure [dbo].[CreateInvestor]
AS
set nocount on

DECLARE @informationSource nvarchar(100)
DECLARE @parenterName nvarchar(100)
DECLARE @Company nvarchar(100)
DECLARE @OrgArea nvarchar(100)
DECLARE @Name nvarchar(100)
DECLARE @TitleName nvarchar(100)
DECLARE @DepartMent nvarchar(100)
DECLARE @eMail nvarchar(100)
DECLARE @mobile nvarchar(100)
DECLARE @wechat nvarchar(100)
DECLARE @IndustryID nvarchar(100)
DECLARE @IndustryID1 nvarchar(100)
DECLARE @Tags nvarchar(100)
DECLARE @Tags1 nvarchar(100)


DECLARE First_cursor CURSOR FOR
select rtrim(ltrim([informationSource])), rtrim(ltrim([parenterName])),rtrim(ltrim([Company])), rtrim(ltrim([OrgArea])), rtrim(ltrim([Name])),rtrim(ltrim([TitleName]))
,rtrim(ltrim([DepartMent])),rtrim(ltrim([eMail])),rtrim(ltrim([mobile])),rtrim(ltrim([wechat])),rtrim(ltrim([IndustryID])),rtrim(ltrim([IndustryID1])),
rtrim(ltrim([Tags])),rtrim(ltrim([Tags1])) FROM [Investor] where name<>''
OPEN First_cursor
FETCH NEXT FROM First_cursor
INTO @informationSource,@parenterName,@Company,@OrgArea,@Name,@TitleName,@DepartMent,@eMail,@mobile,@wechat,@IndustryID,@IndustryID1,@Tags,@Tags1

WHILE @@FETCH_STATUS = 0
BEGIN
	DECLARE @inforID int
	DECLARE @parenterID int
	DECLARE @titleID int
	DECLARE @TagsID int
	DECLARE @IndustryIDint int
	DECLARE @OrgID int
	DECLARE @OrgAreaint int

	if(@informationSource='存量')
		set @inforID = 2
	else if(@informationSource='自然流量')
		set @inforID = 1
	else if(@informationSource='市场流量')
		set @inforID = 3
	else if(@informationSource='项目推送')
		set @inforID = 4
	else if(@informationSource='陌生拜访')
		set @inforID = 5
		
	if(@parenterName='刘璐')
		set @parenterID = 658
	else if(@informationSource='赵鑫')
		set @parenterID = 426
	else if(@informationSource='王启芸')
		set @parenterID = 738
	else if(@informationSource='吴丹彤')
		set @parenterID = 820
	else if(@informationSource='樊杨阳')
		set @parenterID = 164
	
	declare @id int
	if not exists(select * from dbo.[User] where EmailAddress = @eMail)
	begin
		if(@TitleName<>'' or @TitleName is not null)
			select @titleID=id from dbo.Title where TitleC = @TitleName
		
		if(@IndustryID1<>'' or @IndustryID1 is not null)
			select @IndustryIDint=id from dbo.Industry where IndustryC = @IndustryID1
		else if(@IndustryID<>'' or @IndustryID is not null)
			select @IndustryIDint=id from dbo.Industry where IndustryC = @IndustryID
		
		if(@Company<>'' or @Company is not null)
			select @OrgID=id from dbo.Organization where Name = @Company
			
		if(@OrgArea<>'' or @OrgArea is not null)
			select @OrgAreaint = id from dbo.OrgArea where AreaName = @OrgArea
		
		DECLARE @Code nvarchar(50)
		set @Code = 201600000+right(1000000+cast(rand()*10000000 as int)+1,6)
		set @Code = 'default'+@Code
		
		insert into dbo.[User]([PhotoBucket],
								[PhotoKey],
								[CardBucket],
								[CardKey],
								[Mobile],
								[WeChat],
								[ReferencesId],
								[References],
								[HeadId],
								[Head],
								[Sourcesofinformation],
								[Gender],
								[Company],
								[TitleId],
								[IndustryId],
								[OrganizationId],
								[Mandate],
								[AuditStatus],
								[RegisterSource],
								[PartnerId],
								[PartnerName],
								[Score],
								[UserType],
								[AuthenticationSource],
								[Name],
								[Surname],
								[Password],
								[IsEmailConfirmed] ,
								[EmailConfirmationCode],
								[PasswordResetCode],
								[IsActive],
								[UserName] ,
								[TenantId],
								[EmailAddress],
								[LastLoginTime],
								[IsDeleted],
								[DeleterUserId],
								[DeletionTime],
								[LastModificationTime],
								[LastModifierUserId],
								[CreationTime],
								[CreatorUserId],
								[AuditPassTime],
								[AuditNotPassTime],
								[CountryId],
								[OrgAreaId],
								[DepartMent])
								values (null,null,null,null,@mobile,@wechat,null,null,164,'樊杨阳',@inforID,0,
								@Company,@titleID,@IndustryIDint,@OrgID,0,2,4,@parenterID,@parenterName,null,1,null,@Name,@Name,'e10adc3949ba59abbe56e057f20f883e',
								1,null,null,1,@Code,1,@eMail,null,0,null,null,null,null,getdate(),null,null,null,42,@OrgAreaint,@DepartMent)
	end
	--else
	--begin
	--	update dbo.Organization set Currency = @Currencyint where Name = @Name
	--	--if(@DecisionMakingProcess<>'' or @DecisionMakingProcess is not null)
	--	--begin
	--	--	update dbo.Organization set DecisionMakingProcess = @DecisionMakingProcess where Name = @Name
	--	--end
		
	--	--select @id = id from dbo.Organization where Name = @Name
	--	--IF(@OrgLC <>'' OR @OrgLC IS NOT NULL)
	--	--begin
	--	--	 insert into Organization_TransactionPhase select @id, phaseId,0,null,null,null,null,getdate(),null from DBO.F_SQLSERVER_SPLIT(@OrgLC,'；')
	--	--end	
	--end

	
	FETCH NEXT FROM First_cursor
	INTO @informationSource,@parenterName,@Company,@OrgArea,@Name,@TitleName,@DepartMent,@eMail,@mobile,@wechat,@IndustryID,@IndustryID1,@Tags,@Tags1
END

CLOSE First_cursor
DEALLOCATE First_cursor