
CREATE FUNCTION [dbo].[Get_PCode]
(
)
RETURNS nvarchar(50) AS
BEGIN
	DECLARE @maxProjectCode nvarchar(50)
	DECLARE @TodaylastNum int
	DECLARE @Zero nvarchar(4)
	set @Zero = '0000'

	SELECT @TodaylastNum = count(Id) FROM dbo.[Project] where Code like ('P'+CONVERT(varchar(8), GETDATE(), 112) +'%')
	set @TodaylastNum = @TodaylastNum + 1
	set @Zero =substring(@Zero,1,(len(@Zero)-len(@TodaylastNum)))
	
	set @maxProjectCode = 'P'+ CONVERT(varchar(8), GETDATE(), 112)+ @Zero + CONVERT(varchar(8), @TodaylastNum) 
	Return @maxProjectCode
END

