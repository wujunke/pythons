CREATE Procedure [dbo].[UserInfoChange]
AS
set nocount on

DECLARE @Mail nvarchar(200)
DECLARE @Mobile nvarchar(100)
DECLARE @Location nvarchar(100)
DECLARE @Position nvarchar(100)
DECLARE @Industry nvarchar(255)
DECLARE @IndustrySub nvarchar(255)


DECLARE First_cursor CURSOR FOR
select Mail,Mobile,Location,Position,Industry,IndustrySub FROM [InvestargetDb_v2].[dbo].[UserInfo] where Mail <>'10384286@qq.com'
OPEN First_cursor
FETCH NEXT FROM First_cursor
INTO @Mail,@Mobile,@Location,@Position,@Industry,@IndustrySub

WHILE @@FETCH_STATUS = 0
BEGIN
	--fix mobile
	if(@Mobile<>'' or @Mobile is not null)
		update [InvestargetDb_v2].[dbo].[user] set mobile = @Mobile where emailaddress = @Mail
	
	--fix areaId
	declare @AreaId bigint
	if exists(select * from [InvestargetDb_v2].[dbo].[OrgArea] where AreaName = @Location)
	begin
		select @AreaId = id from [InvestargetDb_v2].[dbo].[OrgArea] where AreaName = @Location
		update [InvestargetDb_v2].[dbo].[user] set OrgAreaId = @AreaId where emailaddress = @Mail
	end
	
	--fix titleId
	declare @TitleId bigint
	if exists(select * from [InvestargetDb_v2].[dbo].[Title] where TitleC = @Position)
	begin
		select @TitleId = id from [InvestargetDb_v2].[dbo].[Title] where TitleC = @Position
		update [InvestargetDb_v2].[dbo].[user] set TitleId = @TitleId where emailaddress = @Mail
	end
	
	--fix Industry
	declare @IndustryId bigint
	if(@IndustrySub<>'' or @IndustrySub is not null)
	begin
		select @IndustryId = id from [InvestargetDb_v2].[dbo].[Industry] where IndustryC = @IndustrySub
		update [InvestargetDb_v2].[dbo].[user] set IndustryId = @IndustryId where emailaddress = @Mail
	end
	else if(@Industry<>'' or @Industry is not null)
	begin
		select @IndustryId = id from [InvestargetDb_v2].[dbo].[Industry] where IndustryC = @Industry
		update [InvestargetDb_v2].[dbo].[user] set IndustryId = @IndustryId where emailaddress = @Mail
	end
	
	FETCH NEXT FROM First_cursor
	INTO @Mail,@Mobile,@Location,@Position,@Industry,@IndustrySub
END

CLOSE First_cursor
DEALLOCATE First_cursor
