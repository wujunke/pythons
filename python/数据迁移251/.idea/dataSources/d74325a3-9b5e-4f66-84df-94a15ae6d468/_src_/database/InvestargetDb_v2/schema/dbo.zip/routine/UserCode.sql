CREATE Procedure [dbo].[UserCode]
AS
set nocount on

DECLARE @Code nvarchar(50)
DECLARE @id int

DECLARE First_cursor CURSOR FOR
  select [Id] FROM [InvestargetDB].[dbo].[User] where usertype=1 and createtime>=CONVERT(varchar(100), GETDATE(), 23) and registersource=1
OPEN First_cursor
FETCH NEXT FROM First_cursor
INTO @id

WHILE @@FETCH_STATUS = 0
BEGIN
	if not exists(select * from TempUser where id = @id)
	begin
		set @Code = 201600000+right(1000000+cast(rand()*10000000 as int)+1,6)
		set @Code = 'default'+@Code
		insert into TempUser(id,Code) values(@id,@Code)
	
		if not exists(select * from dbo.[User] a,[InvestargetDB].[dbo].[User] b where a.emailaddress = b.[Personal_mail] and b.id = @id)
		begin
			INSERT INTO dbo.[user] ([PhotoBucket]
		  ,[PhotoKey]
		  ,[CardBucket]
		  ,[CardKey]
		  ,[Mobile]
		  ,[WeChat]
		  ,[ReferencesId]
		  ,[References]
		  ,[HeadId]
		  ,[Head]
		  ,[Sourcesofinformation]
		  ,[Gender]
		  ,[Company]
		  ,[TitleId]
		  ,[IndustryId]
		  ,[OrganizationId]
		  ,[Mandate]
		  ,[AuditStatus]
		  ,[RegisterSource]
		  ,[PartnerId]
		  ,[PartnerName]
		  ,[Score]
		  ,[UserType]
		  ,[AuthenticationSource]
		  ,[Name]
		  ,[Surname]
		  ,[Password]
		  ,[IsEmailConfirmed]
		  ,[EmailConfirmationCode]
		  ,[PasswordResetCode]
		  ,[IsActive]
		  ,[UserName]
		  ,[TenantId]
		  ,[EmailAddress]
		  ,[LastLoginTime]
		  ,[IsDeleted]
		  ,[DeleterUserId]
		  ,[DeletionTime]
		  ,[LastModificationTime]
		  ,[LastModifierUserId]
		  ,[CreationTime]
		  ,[CreatorUserId]
		  ,[AuditPassTime]
		  ,[AuditNotPassTime]
		  ,[CountryId]
		  ,[OrgAreaId]
		  ,[DepartMent]) SELECT 
		  [PhotoBucket]
		  ,[PhotoKey]
		  ,[CardBucket]
		  ,[CardKey]
		  ,[mobile]
		  ,null
		  ,null
		  ,null
		  ,null
		  ,null
		  ,1
		  ,[gender]
		  ,[Company]
		  ,[TitleId]
		  ,[IndustryId]
		  ,null
		  ,0
		  ,1
		  ,[RegisterSource]
		  ,[PartnerId]
		  ,[PartnerName]
		  ,null
		  ,[UserType]
		  ,null
		  ,[Name]
		  ,[Name]
		  ,[Password]
		  ,1
		  ,null
		  ,null
		  ,1
		  ,b.Code
		  ,1
		  ,[Personal_mail]
		  ,null
		  ,0
		  ,null
		  ,null
		  ,null
		  ,null
		  ,[CreateTime]
		  ,null
		  ,[CreateTime]
		  ,null
		  ,[LocationId]
		  ,null
		  ,null
		  FROM [InvestargetDB].[dbo].[User] a,tempuser b where a.id=b.id and b.id=@id
		end
	end
	FETCH NEXT FROM First_cursor
	INTO @id
END

CLOSE First_cursor
DEALLOCATE First_cursor