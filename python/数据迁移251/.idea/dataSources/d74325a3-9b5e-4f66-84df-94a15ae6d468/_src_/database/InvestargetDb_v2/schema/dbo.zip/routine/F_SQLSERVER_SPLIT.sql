CREATE FUNCTION [dbo].[F_SQLSERVER_SPLIT](@Long_str NVARCHAR(MAX),@split_str NVARCHAR(100))    
RETURNS  @tmp TABLE(        
    ID          int IDENTITY PRIMARY KEY,      
    short_str   NVARCHAR(MAX) ,
    PhaseId		bigint   
)    
AS   
BEGIN   
    DECLARE @short_str NVARCHAR(MAX),@split_str_length int,@split_str_Position_Begin int,@PhaseId bigint
    SET @split_str_length = LEN(@split_str) 
    SET @Long_str=REPLACE(REPLACE(@Long_str,CHAR(10),''),CHAR(13),'')
    IF CHARINDEX(@split_str,@Long_str)=1 
         SET @Long_str=STUFF(@Long_str,1,@split_str_length,'')
    IF CHARINDEX(@split_str,@Long_str)=0
        INSERT INTO @tmp SELECT @Long_str,0 
    ELSE
        BEGIN
            WHILE 1>0    
                BEGIN   
                    SET @split_str_Position_Begin = CHARINDEX(@split_str,@Long_str)
                    SET @short_str=LEFT(@Long_str,@split_str_Position_Begin-1) 
                    IF @short_str<>''
                    BEGIN
						INSERT INTO @tmp SELECT @short_str,0
					END  
                    SET @Long_str=STUFF(@Long_str,1,@split_str_Position_Begin+@split_str_length-1,'')
                    SET @split_str_Position_Begin = CHARINDEX(@split_str,@Long_str)
                    IF @split_str_Position_Begin=0 
                    BEGIN
						IF LTRIM(@Long_str)<>''
						BEGIN
							INSERT INTO @tmp SELECT @Long_str,0
						END 
                        BREAK
                    END
                END           
        END		
        Update @tmp set PhaseId = 1 where short_str = '种子天使轮'
        Update @tmp set PhaseId = 4 where short_str = 'A轮'
        Update @tmp set PhaseId = 6 where short_str = 'B轮'
        Update @tmp set PhaseId = 7 where short_str = 'C轮'
        Update @tmp set PhaseId = 8 where short_str = 'C+轮'
        Update @tmp set PhaseId = 11 where short_str = '兼并收购'
        Update @tmp set PhaseId = 10 where short_str = 'Pre-IPO'   
    RETURN     
END