CREATE PROCEDURE `CountOrgBD`(`DataSource` INT(11), `MId` INT(11), `BDStatus` INT(11))
  begin
	select count(username) INTO BDNum from BD_orgbd where manager_id = MId and datasource = DataSource and bd_status_id = BDStatus and is_deleted = 0;
end