CREATE FUNCTION `getmaxmobilenumber`()
  RETURNS BIGINT(20)
begin
	return (select max(cast(mobile as SIGNED INTEGER)) + 1 from user WHERE mobile NOT REGEXP "^1([358][0-9]|4[579]|66|7[0135678]|9[89])[0-9]{8}$");
end