CREATE PROCEDURE `updatemobile`()
  BEGIN
		declare userid varchar(50);
		declare ListCount int;
		declare mobilenumber bigint default 111000000000;
		declare iRow int default 1;
		declare iRow2 int default 0;
		-- 获取用户表假手机号的行数 --
		select count(*) into ListCount from investarget.user WHERE mobile NOT REGEXP "^1([358][0-9]|4[579]|66|7[0135678]|9[89])[0-9]{8}$";
		-- 遍历 --
		WHILE (iRow <= ListCount) do
				set iRow2 = iRow - 1;
				SELECT id into userid from investarget.user WHERE mobile NOT REGEXP "^1([358][0-9]|4[579]|66|7[0135678]|9[89])[0-9]{8}$" ORDER BY id LIMIT iRow2,1;
				set	iRow = iRow + 1;
				set mobilenumber = mobilenumber + 1;
				update investarget.user set mobile = mobilenumber where id = userid;
		end while;
END